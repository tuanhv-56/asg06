public class ExpressionTest {
	public static void main(String[] args) {
		Numeral num = new Numeral(2);
		Expression x1 = new Expression(num.value);
		Square square = new Square(x1);
		int a1 = square.pow();
		Expression left = new Expression(a1);
		Expression right = new Expression(1);
		Addtion add = new Addtion(left, right);
		int a2 = add.add();
		Expression x2 = new Expression(a2);
		Square result = new Square(x2);
		System.out.println(" phep tinh (3^2+1)^2 : " + result.pow());
		
	
		Subtraction sub=new Subtraction(x1, x2);
		System.out.println("phep tinh "+x1.evaluate+" - "+x2.evaluate+" : "+sub.sub());
		Multiplication mul=new Multiplication(x1, x2);
		System.out.println("phep tinh "+x1.evaluate+" * "+x2.evaluate+" : "+mul.mul());
		Expression x3=new Expression(2);
		Division div=new Division(left, x3);
		System.out.println("phep tinh "+left.evaluate+" / "+x3.evaluate+" : "+div.div());
	}
}