public class Division implements BinaryExpression {
	private Expression left;
	private Expression right;

@Override
	public Expression left() {
		
		return this.left;
	}

	
	public Expression right() {
		
		return this.right;
	}

	public Division(Expression ex1, Expression ex2) {
		this.left = ex1;
		this.right = ex2;
	}

	public double div() {
		if (this.right.evaluate == 0) {
			System.out.println("khong the thu hien");
			return 0;
		}
		else
			return this.left.evaluate*1.0 / this.right.evaluate;
	}
}