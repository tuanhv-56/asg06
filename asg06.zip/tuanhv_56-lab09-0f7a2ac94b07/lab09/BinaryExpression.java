interface BinaryExpression {
	public Expression left();

	public  Expression right();
}