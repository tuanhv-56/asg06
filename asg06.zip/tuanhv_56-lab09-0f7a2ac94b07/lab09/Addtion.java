public class Addtion implements BinaryExpression{
	private Expression left;
	private  Expression right;
	@Override
	public Expression left() {
		
		return this.left;
	}
	
	public Expression right() {
		
		return this.right;
	}
	public Addtion(Expression ex1,Expression ex2) {
		this.left=ex1;
		this.right=ex2;
	}
	public int add() {
		return this.left.evaluate+this.right.evaluate;
	}
}