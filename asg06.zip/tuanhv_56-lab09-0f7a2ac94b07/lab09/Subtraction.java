public class Subtraction implements BinaryExpression {
	private Expression left;
	private Expression right;

	@Override
	public Expression left() {
		// TODO Auto-generated method stub
		return this.left;
	}

	@Override
	public Expression right() {
		// TODO Auto-generated method stub
		return this.right;
	}

	public Subtraction(Expression x1, Expression x2) {
		this.left = x1;
		this.right = x2;
	}

	public int sub() {
		return this.left.evaluate - this.right.evaluate;
	}
}