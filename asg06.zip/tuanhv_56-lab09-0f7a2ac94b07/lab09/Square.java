public class Square {
	public Expression expression;
	public Square(Expression x) {
		this.expression=x;
	}
	public int pow() {
		return (int)Math.pow(this.expression.evaluate, 2);
	}
}