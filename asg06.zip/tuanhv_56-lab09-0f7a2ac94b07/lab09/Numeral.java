public class Numeral {
	public int value;

	public Numeral() {
		this.value = 0;
	}

	public Numeral(int data) {
		this.value = data;
	}

	@Override
	public String toString() {
		
		return this.value + " ";
	}}