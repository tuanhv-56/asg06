public class Multiplication implements BinaryExpression {
	private Expression left;
	private Expression right;
	
	public Expression left() {
		
		return this.left;
	}

	
	public Expression right() {
		
		return this.right;
	}

	public Multiplication(Expression x1, Expression x2) {
		this.left = x1;
		this.right = x2;
	}

	public int mul() {
		return this.left.evaluate * this.right.evaluate;
	}}