public class Expression {
	public int evaluate;

	public Expression(int data) {
		this.evaluate = data;
	}

	public String toString() {
		return this.evaluate + "";
	}
}